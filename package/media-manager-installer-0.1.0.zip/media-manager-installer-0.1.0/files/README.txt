Media Manager v0.1.0 - Portable Version
==================================================

This is a portable version of Media Manager. No installation is required.

System Requirements:
- Windows 7 or higher
- 64-bit operating system  
- 500MB free disk space
- .NET Framework 4.5 or higher (usually pre-installed)

Getting Started:
1. Double-click media-manager.exe to launch the application
2. The application will create configuration files in:
   %USERPROFILE%\.media-manager\

Features:
- Media scanning and organization
- Automatic metadata matching
- Poster downloading
- subtitle management
- NFO file generation
- And much more!

Support:
For documentation and support, please refer to the project documentation.

Version: 0.1.0
Build Date: 2024-11-09 07:04:00
Build System: Linux (placeholder - requires Windows build)

NOTE: This is a template file. The actual portable package
will be created when running the build script on Windows.